import React from 'react';
import Logo from '../assets/images/site-logo.svg';

export default function Header() {
  return (
        <nav className="navbar navbar-expand-lg ">
            <div className="container">
                <a className="navbar-brand" href="/">
                    <img src={Logo}/></a>
                <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#togglenav" aria-controls="togglenav" aria-expanded="false" aria-label="Toggle navigation">
                <span className="navbar-toggler-icon"></span>
                </button>
                <div className="collapse navbar-collapse" id="togglenav">
                <ul className="navbar-nav me-auto mb-2 mb-lg-0">
                <li className="nav-item dropdown">
                    <a className="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    Solutions 
                    </a>
                    <ul className="dropdown-menu">
                        <li><a className="dropdown-item" href="#">Action</a></li>
                        <li><a className="dropdown-item" href="#">Another action</a></li>
                        <li><a className="dropdown-item" href="#">Something else here</a></li>
                    </ul>
                    </li>
                    <li className="nav-item">
                    <a className="nav-link active" aria-current="page" href="#">How it works</a>
                    </li>
                    <li className="nav-item">
                    <a className="nav-link" href="#">Pricing</a>
                    </li>
                    
                    <li className="nav-item">
                    <a className="nav-link "  href="#">FAQ</a>
                    </li>
                    <li className="nav-item">
                    <a className="nav-link "  href="#">Resources</a>
                    </li>
                </ul>
                <div className="headr_btns">
                    <button className="CTA">Log in</button>
                    <button className="Cta">Sign up</button>
                </div>
                </div>
            </div>
            </nav>
 
  )
}
