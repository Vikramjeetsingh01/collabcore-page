import React from 'react';
import Smilinggirl from 'assets/images/girl-smiling.webp'

export default function Foragencies() {
  return (
    <div className="row align-items-center">
    <div className="col-md-6">
      <div className="txt_blk">
        <span className="Badges">For Agencies</span>
        <h2>A better system for creator management.</h2>
        <p>Maximize your agency's productivity by simplifying creator management and brand deal coordination, all in one user-friendly platform.</p>
      </div>
      <div className="list_blk">
        <ul>
          <li>Multiple Creator Management</li>
          <li>Team Features</li>
          <li>Synced Calendar</li>
          <li>Business Messenger</li>
        </ul>
      </div>
    </div> 
    <div className="col-md-6">
      <div className="blk_img">
        <img src={Smilinggirl} alt="girl" />
      </div>
    </div>
  </div>
  )
}
