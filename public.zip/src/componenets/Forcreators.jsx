import React from 'react';
import { Link } from 'react-router-dom';
import Girlimage from 'assets/images/girl.webp'

export default function Forcreators() {
  return (
    <div className="row align-items-center">
      <div className="col-md-6">
        <div className="txt_blk">
          <span className="Badges">For Creators</span>
          <h2>The way collaboration should be.</h2>
          <p>Experience stress-free collaborations with the highest organization. <Link to=""> Create an account </Link> — no hassle sign up</p>
        </div>
        <div className="list_blk">
          <ul>
            <li>Spam-Free Inbox</li>
            <li>Synced Calendar</li>
            <li>Business Messenger</li>
            <li>Vital Statistics</li>
          </ul>
        </div>
      </div> 
      <div className="col-md-6">
        <div className="blk_img">
          <img src={Girlimage} alt="girl" />
        </div>
      </div>
    </div>
  )
}
