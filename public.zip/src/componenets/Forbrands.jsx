import React from 'react'
import Teamimage from 'assets/images/team.webp'

export default function Forbrands() {
  return (
    <div className="row align-items-center">
      <div className="col-md-6">
        <div className="txt_blk">
          <span className="Badges">For Brands</span>
          <h2>Reach the creators you want.</h2>
          <p>Boost click-through rates by messaging creators on a platform built for collaboration.</p>
        </div>
        <div className="list_blk">
          <ul>
            <li>Authentic Creator Ecosystem</li>
            <li>High Response Rate</li>
            <li>Organized Campaigns</li>
            <li>Team features</li>
          </ul>
        </div>
      </div> 
      <div className="col-md-6">
        <div className="blk_img">
          <img src={Teamimage} alt="girl" />
        </div>
      </div>
    </div>
  )
}
