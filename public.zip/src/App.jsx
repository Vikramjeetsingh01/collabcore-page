import "bootstrap/dist/css/bootstrap.min.css";
import { AllRoutes } from './routes';
import { useEffect } from 'react';
import 'stylesheet/Styles.css';
import './layout/Layout.css';

function App() {
  useEffect(() => {
    require("bootstrap/dist/js/bootstrap.js");
  }, []);
  return (
    <AllRoutes />
  );
}

export default App;
